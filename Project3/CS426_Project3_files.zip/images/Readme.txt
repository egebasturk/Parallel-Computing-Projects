## 	CS426 Project 3	
##	DATA SET DETAILS
	1.	Each file contains 180x200 matrices
	2.	Each file names in the following format
		person_id.img_id.txt
		
		1.1.	There are 18 persons' images
		1.2.	There 20 image for each person
		
	3.	Original data set can be found in the following link
		http://cswww.essex.ac.uk/mv/allfaces/grimace.html
	4.	Images are preprocessed and converted to matrix format
